import { ConfirmDialog } from '@/components/ui/blih';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Award,
  Briefcase,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Download,
  Eye,
  FileSignature,
  FileText,
  Filter,
  Hourglass,
  Lock,
  MoreVertical,
  Pencil,
  Plus, Search,
  ShieldCheck,
  ShieldOff,
  Trash,
  Upload,
  UserCog,
  Users,
  UserX,
  XCircle
} from 'lucide-react';
import EmployeeContractMenuAction from "../contracts/EmployeeContractMenuAction";
import EmployeeContractViewerModal from "../contracts/EmployeeContractViewerModal";
import { AnimatePresence, motion } from 'motion/react';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLegacyUser } from '../../api/legacyUserStore';
import {
  useAllRoles,
  useApproveUserExemption,
  useCreateUserExemption,
  useDeleteEmployee,
  useEmployees,
  useOrganogram,
  useRejectUserExemption,
  useRevokeUserExemption,
  useUpdateEmployeePassword,
  useUpdateEmployeeRole,
  useUserExemptions,
  type UserExemption,
} from '../../hooks/useHrRecords';
import { useMyPermissions } from '../../hooks/usePermissions';
import BulkEmployeeImportPage from '../../pages/BulkEmployeeImportPage';
import ImmediateTerminationModal from "../offboarding/modals/ImmediateTerminationModal";
import CreateEmployeeModal from './CreateEmployeeModal';
import DepartmentsPositionsTab from './DepartmentsPositionsTab';
import PeopleProfileDraftsPanel from './drafts/PeopleProfileDraftsPanel';
import EmployeeDevicesTab from './EmployeeDevicesTab';
import EventsTab from './EventsTab';
import PendingRegistrationsTab from './PendingRegistrationsTab';
import AssignEmployeeContractModal from "../contracts/AssignEmployeeContractModal";
import { InitializeProbationDialog } from "../../features/probation/components/InitializeProbationDialog";
interface OrgNode {
  id: string;
  userId?: string;
  type?: 'admin' | 'department' | 'employee';
  name: string;
  title: string;
  department: string;
  avatar?: string;
  children: OrgNode[];
}

// ─── Layout constants ─────────────────────────────────────────────────────────
const NODE_W = 160;
const NODE_H = 80;
const H_GAP = 40;   // horizontal gap between siblings
const V_GAP = 80;   // vertical gap between levels

// ─── Measure subtree width ────────────────────────────────────────────────────
function subtreeWidth(node: OrgNode): number {
  if (node.children.length === 0) return NODE_W;
  const childrenTotal = node.children.reduce((s, c) => s + subtreeWidth(c), 0);
  const gaps = (node.children.length - 1) * H_GAP;
  return Math.max(NODE_W, childrenTotal + gaps);
}

// ─── Assign x/y to every node ────────────────────────────────────────────────
interface PositionedNode {
  node: OrgNode;
  x: number;
  y: number;
  children: PositionedNode[];
}

function layoutTree(node: OrgNode, x: number, y: number): PositionedNode {
  if (node.children.length === 0) {
    return { node, x, y, children: [] };
  }
  const widths = node.children.map(subtreeWidth);
  const totalW = widths.reduce((s, w) => s + w, 0) + (node.children.length - 1) * H_GAP;
  let cursor = x - totalW / 2;
  const positioned: PositionedNode[] = node.children.map((child, i) => {
    const cw = widths[i];
    const cx = cursor + cw / 2;
    cursor += cw + H_GAP;
    return layoutTree(child, cx, y + NODE_H + V_GAP);
  });
  return { node, x, y, children: positioned };
}

// ─── Collect all nodes + edges ────────────────────────────────────────────────
function collectNodes(pn: PositionedNode, nodes: PositionedNode[], edges: { x1: number; y1: number; x2: number; y2: number }[]) {
  nodes.push(pn);
  pn.children.forEach(child => {
    edges.push({
      x1: pn.x,
      y1: pn.y + NODE_H,
      x2: child.x,
      y2: child.y,
    });
    collectNodes(child, nodes, edges);
  });
}

// ─── Bounding box ─────────────────────────────────────────────────────────────
function getBounds(nodes: PositionedNode[]) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  nodes.forEach(n => {
    minX = Math.min(minX, n.x - NODE_W / 2);
    minY = Math.min(minY, n.y);
    maxX = Math.max(maxX, n.x + NODE_W / 2);
    maxY = Math.max(maxY, n.y + NODE_H);
  });
  return { minX, minY, maxX, maxY, w: maxX - minX, h: maxY - minY };
}

// ─── Single node card ─────────────────────────────────────────────────────────
function OrgCard({ pn, onSelect }: { pn: PositionedNode; onSelect: (n: OrgNode) => void; key?: React.Key }) {
  const { node, x, y } = pn;
  const initials = node.name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);
  const hasChildren = node.children.length > 0;
  const isDepartment = node.type === 'department';

  return (
    <div
      onClick={() => !isDepartment && onSelect(node)}
      style={{
        position: 'absolute',
        left: x - (isDepartment ? 190 : NODE_W) / 2,
        top: y,
        width: isDepartment ? 190 : NODE_W,
        height: NODE_H,
      }}
      className={`${isDepartment ? 'cursor-default' : 'cursor-pointer'} group select-none`}
    >
      <div className={`w-full h-full rounded-xl border-2 shadow-sm transition-all flex flex-col items-center justify-center px-2 py-2 relative ${isDepartment
          ? 'bg-blue-50 border-blue-500'
          : `${hasChildren ? 'border-blue-500' : 'border-slate-200'} bg-white hover:shadow-md hover:border-blue-400`
        }`}>
        {!isDepartment && node.department && (
          <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase tracking-widest bg-blue-600 text-white px-2 py-0.5 rounded-full whitespace-nowrap">
            {node.department}
          </span>
        )}
        {isDepartment ? (
          <>
            <Briefcase className="w-5 h-5 text-blue-600 mb-1.5" />
            <p className="text-[11px] font-black text-blue-950 truncate w-full text-center leading-tight uppercase tracking-wide">{node.name}</p>
            <p className="text-[8px] text-blue-500 font-black truncate w-full text-center mt-1 uppercase tracking-widest">{node.title}</p>
          </>
        ) : (
          <>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-black text-[10px] mb-1 flex-shrink-0">
              {node.avatar
                ? <img src={node.avatar} className="w-full h-full rounded-full object-cover" alt={initials} />
                : initials}
            </div>
            <p className="text-[10px] font-black text-slate-900 truncate w-full text-center leading-tight">{node.name}</p>
            <p className="text-[8px] text-slate-400 font-semibold truncate w-full text-center mt-0.5">{node.title}</p>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Full org chart canvas ────────────────────────────────────────────────────
function OrgChartCanvas({ roots, onSelect }: { roots: OrgNode[]; onSelect: (n: OrgNode) => void }) {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const [pan, setPan] = React.useState({ x: 0, y: 0 });
  const [scale, setScale] = React.useState(1);
  const dragging = React.useRef(false);
  const lastPos = React.useRef({ x: 0, y: 0 });

  // Build layout for all roots side by side
  const allNodes: PositionedNode[] = [];
  const allEdges: { x1: number; y1: number; x2: number; y2: number }[] = [];

  let cursor = 0;
  const rootLayouts: PositionedNode[] = roots.map(root => {
    const sw = subtreeWidth(root);
    const layout = layoutTree(root, cursor + sw / 2, 0);
    cursor += sw + H_GAP * 2;
    return layout;
  });

  rootLayouts.forEach(rl => collectNodes(rl, allNodes, allEdges));

  const bounds = allNodes.length > 0 ? getBounds(allNodes) : { minX: 0, minY: 0, w: 400, h: 300 };
  const PAD = 60;
  const canvasW = bounds.w + PAD * 2;
  const canvasH = bounds.h + PAD * 2;
  const offsetX = -bounds.minX + PAD;
  const offsetY = -bounds.minY + PAD;

  // Center on mount
  React.useEffect(() => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const fitScale = Math.min(1, (clientWidth - 40) / canvasW, (clientHeight - 40) / canvasH);
    setScale(fitScale);
    setPan({
      x: (clientWidth - canvasW * fitScale) / 2,
      y: (clientHeight - canvasH * fitScale) / 2,
    });
  }, [roots.length]);

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setScale(s => Math.min(2, Math.max(0.2, s * delta)));
  };

  const onMouseDown = (e: React.MouseEvent) => {
    dragging.current = true;
    lastPos.current = { x: e.clientX, y: e.clientY };
  };

  const onMouseMove = (e: React.MouseEvent) => {
    if (!dragging.current) return;
    const dx = e.clientX - lastPos.current.x;
    const dy = e.clientY - lastPos.current.y;
    lastPos.current = { x: e.clientX, y: e.clientY };
    setPan(p => ({ x: p.x + dx, y: p.y + dy }));
  };

  const onMouseUp = () => { dragging.current = false; };

  const zoomIn = () => setScale(s => Math.min(2, parseFloat((s * 1.2).toFixed(3))));
  const zoomOut = () => setScale(s => Math.max(0.2, parseFloat((s / 1.2).toFixed(3))));
  const resetView = () => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const fitScale = Math.min(1, (clientWidth - 40) / canvasW, (clientHeight - 40) / canvasH);
    setScale(fitScale);
    setPan({ x: (clientWidth - canvasW * fitScale) / 2, y: (clientHeight - canvasH * fitScale) / 2 });
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full overflow-hidden relative bg-[#f8fafc] cursor-grab active:cursor-grabbing"
      onWheel={onWheel}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
    >
      {/* Dot grid background */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ opacity: 0.4 }}>
        <defs>
          <pattern id="dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#cbd5e1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots)" />
      </svg>

      {/* Transformed canvas */}
      <div
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
          transformOrigin: '0 0',
          position: 'absolute',
          width: canvasW,
          height: canvasH,
        }}
      >
        {/* SVG connectors */}
        <svg
          style={{ position: 'absolute', top: 0, left: 0, width: canvasW, height: canvasH, overflow: 'visible', pointerEvents: 'none' }}
        >
          {allEdges.map((e, i) => {
            const x1 = e.x1 + offsetX;
            const y1 = e.y1 + offsetY;
            const x2 = e.x2 + offsetX;
            const y2 = e.y2 + offsetY;
            const midY = (y1 + y2) / 2;
            return (
              <path
                key={i}
                d={`M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`}
                fill="none"
                stroke="#93c5fd"
                strokeWidth="1.5"
                strokeDasharray="none"
              />
            );
          })}
        </svg>

        {/* Node cards */}
        {allNodes.map((pn, i) => {
          const nodeKey = String(pn.node.id || i);
          return (
            <OrgCard
              key={nodeKey}
              pn={{ ...pn, x: pn.x + offsetX, y: pn.y + offsetY }}
              onSelect={onSelect}
            />
          );
        })}
      </div>

      {/* Zoom controls */}
      <div className="absolute bottom-4 right-4 flex items-center gap-1">
        <button
          onClick={(e) => { e.stopPropagation(); zoomOut(); }}
          className="w-7 h-7 bg-white border border-slate-200 rounded-lg shadow-sm flex items-center justify-center text-slate-600 hover:bg-slate-50 hover:border-slate-300 transition-colors text-sm font-black select-none"
          title="Zoom out"
        >−</button>
        <button
          onClick={(e) => { e.stopPropagation(); resetView(); }}
          className="h-7 px-2 bg-white border border-slate-200 rounded-lg shadow-sm flex items-center justify-center text-[10px] font-black text-slate-500 hover:bg-slate-50 hover:border-slate-300 transition-colors select-none min-w-[44px]"
          title="Reset view"
        >{Math.round(scale * 100)}%</button>
        <button
          onClick={(e) => { e.stopPropagation(); zoomIn(); }}
          className="w-7 h-7 bg-white border border-slate-200 rounded-lg shadow-sm flex items-center justify-center text-slate-600 hover:bg-slate-50 hover:border-slate-300 transition-colors text-sm font-black select-none"
          title="Zoom in"
        >+</button>
      </div>
    </div>
  );
}

interface PeopleProfilesViewProps {
  currentProfilesTab: 'create' | 'bulk_create' | 'organogram' | 'directory' | 'left' | 'interns' | 'organization' | 'devices' | 'events' | 'archive' | 'pending_registrations' | 'exemption_requests';
  onDraftAiSuggestion: (context: string) => void;
  showAlert: (title: string, type?: 'success' | 'info' | 'error') => void;
  onViewProfile?: (employee: any) => void;
}

export default function PeopleProfilesView({
  currentProfilesTab,
  onDraftAiSuggestion,
  showAlert,
  onViewProfile,
}: PeopleProfilesViewProps) {
  const navigate = useNavigate();
  // Directory & Archive Selection States
  const [selectedDirectoryRow, setSelectedDirectoryRow] = useState<number>(0);
  const [selectedArchiveRow, setSelectedArchiveRow] = useState<number>(0);
  const [
    terminationEmployee,
    setTerminationEmployee,
  ] = useState<any | null>(null);
  const [
    contractEmployee,
    setContractEmployee,
  ] = useState<any | null>(null);
  const [
    probationEmployee,
    setProbationEmployee,
  ] = useState<any | null>(null);
  const [
    viewerContractId,
    setViewerContractId,
  ] = useState<string | null>(null);

  // Search/Filters states
  const [directionSearch, setDirectionSearch] = useState<string>('');
  const [deptFilter, setDeptFilter] = useState<string>('Marketing');
  const [archiveSearch, setArchiveSearch] = useState<string>('');
  const [archiveDeptFilter, setArchiveDeptFilter] = useState<string>('Marketing');

  // Interactive Form Creation States (Create Tab)
  // Draft creation UI is handled in PeopleProfileDraftsPanel

  const [activeEventCategory, setActiveEventCategory] = useState<'birthdays' | 'anniversaries' | 'promotions' | 'holidays'>('birthdays');

  // Organogram & Directory — React Query hooks
  const [currentPage, setCurrentPage] = useState(1);
  const [internsPage, setInternsPage] = useState(1);
  const employeesPerPage = 10;
  const [activeActionsMenu, setActiveActionsMenu] = useState<string | null>(null);
  const [updateEmployeeModalOpen, setUpdateEmployeeModalOpen] = useState(false);
  const [updateEmployeeUserId, setUpdateEmployeeUserId] = useState<string | null>(null);
  const [deleteEmployeeUserId, setDeleteEmployeeUserId] = useState<string | null>(null);
  const [passwordEmployee, setPasswordEmployee] = useState<any | null>(null);
  const [roleEmployee, setRoleEmployee] = useState<any | null>(null);
  const [exemptionEmployee, setExemptionEmployee] = useState<any | null>(null);
  const [unexemptTarget, setUnexemptTarget] = useState<{ employee: any; exemption: UserExemption } | null>(null);
  const [exemptionForm, setExemptionForm] = useState({ reason: '', excludeFromPayroll: false });
  const [exemptionError, setExemptionError] = useState('');
  const [passwordForm, setPasswordForm] = useState({ password: '', confirmPassword: '' });
  const [passwordError, setPasswordError] = useState('');
  const [selectedRoleKey, setSelectedRoleKey] = useState('');
  const [roleError, setRoleError] = useState('');
  const [createInternModalOpen, setCreateInternModalOpen] = useState(false);
  const perms = useMyPermissions();
  const legacyUser = useLegacyUser();

  const { data: orgResult, isLoading: loadingOrg, refetch: refetchOrg } = useOrganogram();
  const orgData: OrgNode[] = (orgResult as any) ?? [];
  const { data: allRoles = [], isLoading: loadingRoles } = useAllRoles();

  const { data: empResult, isLoading: loadingEmployees, refetch: refetchEmployees } = useEmployees({
    limit: employeesPerPage,
    offset: (currentPage - 1) * employeesPerPage,
  });
  const employees: any[] = empResult?.employees ?? [];
  const totalEmployees: number = empResult?.total ?? 0;
  const { data: internResult, isLoading: loadingInterns, refetch: refetchInterns } = useEmployees({
    limit: employeesPerPage,
    offset: (internsPage - 1) * employeesPerPage,
    employmentType: "intern",
  });
  const interns: any[] = internResult?.employees ?? [];
  const totalInterns: number = internResult?.total ?? 0;
  const { data: leftResult, isLoading: loadingLeftEmployees, refetch: refetchLeftEmployees } = useEmployees({
    limit: employeesPerPage,
    offset: 0,
    employmentStatus: "terminated",
  });
  const leftEmployees: any[] = leftResult?.employees ?? [];
  const totalLeftEmployees: number = leftResult?.total ?? 0;

  const deleteEmployeeMutation = useDeleteEmployee();
  const updatePasswordMutation = useUpdateEmployeePassword();
  const updateRoleMutation = useUpdateEmployeeRole();
  const createExemptionMutation = useCreateUserExemption();
  const approveExemptionMutation = useApproveUserExemption();
  const rejectExemptionMutation = useRejectUserExemption();
  const revokeExemptionMutation = useRevokeUserExemption();
  const exemptionRequests = useUserExemptions({
    status: currentProfilesTab === 'exemption_requests' ? 'PENDING' : 'all',
    size: currentProfilesTab === 'exemption_requests' ? 50 : 100,
  });

  const getEmployeeUserId = (employee: any) => employee?.userId || employee?.user?.id || employee?.id;
  const getEmployeeRoles = (employee: any) => {
    const roles =
      employee?.user?.Roles ||
      employee?.user?.roles ||
      employee?.Roles ||
      employee?.roles ||
      employee?.User?.Roles ||
      employee?.User?.roles ||
      [];
    if (Array.isArray(roles)) return roles;
    return roles ? [roles] : [];
  };
  const getEmployeeRoleKey = (employee: any) => {
    const role = getEmployeeRoles(employee)[0];
    return typeof role === 'string'
      ? role
      : role?.key || employee?.roleKey || employee?.requestedRoleKey || employee?.user?.roleKey || '';
  };
  const getEmployeeRoleLabel = (employee: any) => {
    const role = getEmployeeRoles(employee)[0];
    const roleKey = getEmployeeRoleKey(employee);
    const roleFromOptions = allRoles.find((item: any) => item.key === roleKey);
    if (roleFromOptions) return roleFromOptions.name || roleFromOptions.key;
    return typeof role === 'string' ? role : role?.name || role?.key || roleKey || 'No role assigned';
  };
  const selectedRoleLabel = allRoles.find((role: any) => role.key === selectedRoleKey)?.name || selectedRoleKey;
  const canRequestExemption = perms.hasAny('hr.write', 'user.update', 'attendance.manage');
  const canTerminateEmployee =
    perms.hasAny("hr.write") ||
    perms.isSuperAdmin ||
    legacyUser?.role === "Business Admin";
  const canAssignContract =
    perms.hasAny(
      "hr.write",
      "onboarding.manage",
      "offer.approve",
    ) ||
    perms.isSuperAdmin ||
    legacyUser?.role ===
      "Business Admin";
  const canInitializeProbation =
    perms.hasAny(
      "hr.write",
      "onboarding.manage",
      "performance.manage",
    ) ||
    perms.isSuperAdmin ||
    legacyUser?.role ===
      "Business Admin";
  const canApproveExemption = perms.isSuperAdmin || legacyUser?.role === 'Business Admin';
  const exemptionsByUserId = React.useMemo(() => {
    const map = new Map<string, UserExemption>();
    for (const row of exemptionRequests.data?.rows || []) {
      const existing = map.get(row.userId);
      if (!existing || row.status === 'APPROVED' || existing.status !== 'APPROVED') map.set(row.userId, row);
    }
    return map;
  }, [exemptionRequests.data?.rows]);

  const fetchOrganogram = () => refetchOrg();
  const fetchEmployees = (page: number = 1) => {
    setCurrentPage(page);
    refetchEmployees();
  };

  const handleDeleteEmployee = async (userId: string) => {
    try {
      await deleteEmployeeMutation.mutateAsync(userId);
      setDeleteEmployeeUserId(null);
      showAlert("Employee record deleted successfully", "success");
    } catch (e: any) {
      showAlert(e.message || "Failed to delete record", "error");
    }
  };

  const openPasswordModal = (employee: any) => {
    setPasswordEmployee(employee);
    setPasswordForm({ password: '', confirmPassword: '' });
    setPasswordError('');
  };

  const openRoleModal = (employee: any) => {
    setRoleEmployee(employee);
    setSelectedRoleKey(getEmployeeRoleKey(employee));
    setRoleError('');
  };

  const openExemptionModal = (employee: any) => {
    setExemptionEmployee(employee);
    setExemptionForm({ reason: '', excludeFromPayroll: false });
    setExemptionError('');
  };

  const closePasswordModal = () => {
    if (updatePasswordMutation.isPending) return;
    setPasswordEmployee(null);
    setPasswordForm({ password: '', confirmPassword: '' });
    setPasswordError('');
  };

  const closeRoleModal = () => {
    if (updateRoleMutation.isPending) return;
    setRoleEmployee(null);
    setSelectedRoleKey('');
    setRoleError('');
  };

  const closeExemptionModal = () => {
    if (createExemptionMutation.isPending) return;
    setExemptionEmployee(null);
    setExemptionForm({ reason: '', excludeFromPayroll: false });
    setExemptionError('');
  };

  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordEmployee) return;
    const password = passwordForm.password.trim();
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters.');
      return;
    }
    if (password !== passwordForm.confirmPassword.trim()) {
      setPasswordError('Passwords do not match.');
      return;
    }

    try {
      await updatePasswordMutation.mutateAsync({ userId: getEmployeeUserId(passwordEmployee), password });
      closePasswordModal();
      showAlert('Employee password updated successfully', 'success');
    } catch (e: any) {
      setPasswordError(e?.response?.data?.message || e?.message || 'Failed to update password.');
    }
  };

  const handleRoleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleEmployee) return;
    if (!selectedRoleKey) {
      setRoleError('Select a role to continue.');
      return;
    }

    try {
      await updateRoleMutation.mutateAsync({ userId: getEmployeeUserId(roleEmployee), roleKey: selectedRoleKey });
      closeRoleModal();
      showAlert('Employee role updated successfully', 'success');
    } catch (e: any) {
      setRoleError(e?.response?.data?.message || e?.message || 'Failed to update role.');
    }
  };

  const handleExemptionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!exemptionEmployee) return;
    const reason = exemptionForm.reason.trim();
    if (!reason) {
      setExemptionError('Exemption reason is required.');
      return;
    }
    if (reason.length < 8) {
      setExemptionError('Please provide a clearer exemption reason.');
      return;
    }
    try {
      await createExemptionMutation.mutateAsync({
        userId: getEmployeeUserId(exemptionEmployee),
        reason,
        excludeFromPayroll: exemptionForm.excludeFromPayroll,
      });
      closeExemptionModal();
      showAlert('Exemption request submitted for Business Admin approval', 'success');
    } catch (e: any) {
      setExemptionError(e?.response?.data?.message || e?.response?.data?.error || e?.message || 'Failed to submit exemption request.');
    }
  };

  const handleApproveExemption = async (id: string) => {
    try {
      await approveExemptionMutation.mutateAsync(id);
      showAlert('Exemption request approved', 'success');
    } catch (e: any) {
      showAlert(e?.response?.data?.message || e?.response?.data?.error || e?.message || 'Failed to approve exemption', 'error');
    }
  };

  const handleRejectExemption = async (id: string) => {
    try {
      await rejectExemptionMutation.mutateAsync(id);
      showAlert('Exemption request rejected', 'info');
    } catch (e: any) {
      showAlert(e?.response?.data?.message || e?.response?.data?.error || e?.message || 'Failed to reject exemption', 'error');
    }
  };

  const handleUnexemptUser = async () => {
    if (!unexemptTarget) return;
    try {
      await revokeExemptionMutation.mutateAsync(unexemptTarget.exemption.id);
      showAlert('User exemption removed', 'success');
      setUnexemptTarget(null);
    } catch (e: any) {
      showAlert(e?.response?.data?.message || e?.response?.data?.error || e?.message || 'Failed to remove exemption', 'error');
    }
  };
  return (
    <div className="h-full flex flex-col space-y-6">
      <AnimatePresence mode="wait">

        {/* --- 2. CREATE SCREEN (IMAGE 2) --- */}
        {currentProfilesTab === 'create' && (
          <motion.div
            key="create"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <PeopleProfileDraftsPanel showAlert={showAlert} />
          </motion.div>
        )}

        {currentProfilesTab === 'bulk_create' && (
          <motion.div
            key="bulk_create"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <BulkEmployeeImportPage />
          </motion.div>
        )}

        {/* --- 3. ORGANOGRAM SCREEN --- */}
        {currentProfilesTab === 'organogram' && (
          <motion.div
            key="organogram"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-black text-slate-900 tracking-tight">Organization Chart</h4>
                <p className="text-[11px] text-slate-500 font-medium">Hierarchy and profiles of all employees</p>
              </div>
              <button
                onClick={() => refetchOrg()}
                disabled={loadingOrg}
                className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors disabled:opacity-40"
              >
                {loadingOrg ? 'Loading…' : '↺ Refresh'}
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden" style={{ height: 580 }}>
              {loadingOrg ? (
                <div className="flex flex-col items-center justify-center h-full gap-4">
                  <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Building chart…</span>
                </div>
              ) : orgData.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-3">
                  <Users className="w-12 h-12 text-slate-200" />
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No employee hierarchy found</p>
                  <button onClick={refetchOrg} className="text-[11px] font-black text-blue-600 hover:underline">Retry</button>
                </div>
              ) : (
                <OrgChartCanvas
                  roots={orgData}
                  onSelect={(n) => onViewProfile?.(n)}
                />
              )}
            </div>

            <p className="text-center text-[10px] text-slate-400 font-semibold">
              💡 Scroll to zoom · Drag to pan · Click a card to view profile · Click % to reset view
            </p>
          </motion.div>
        )}

        {/* --- 4. DIRECTORY SCREEN (IMAGE 4) --- */}
        {currentProfilesTab === 'directory' && (
          <motion.div
            key="directory"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div className="flex justify-between items-end">
              <div>
                <h4 className="text-sm font-bold text-slate-950 tracking-tight">All Employees & Profiles</h4>
                <p className="text-[11px] text-slate-500 font-medium">Directory of employees and profiles</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => navigate('../bulk_create')}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-[11px] font-black text-white hover:bg-blue-700"
                >
                  <Upload className="w-3.5 h-3.5" /> Bulk Import Employees
                </button>
                <button
                  onClick={() => refetchEmployees()}
                  disabled={loadingEmployees}
                  className="text-[10px] font-black text-blue-600 flex items-center gap-1 hover:underline disabled:opacity-50"
                >
                  {loadingEmployees ? 'Reloading...' : 'Reload Roster'}
                </button>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">

              {/* Dynamic Search / Custom Filters Row */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={directionSearch}
                    onChange={(e) => setDirectionSearch(e.target.value)}
                    placeholder="Search employees..."
                    className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-150 rounded-xl py-2 pl-10 pr-4 text-xs font-semibold text-slate-700 placeholder-slate-400 focus:outline-none focus:bg-white"
                  />
                </div>

                <button
                  onClick={() => showAlert('Reset active table parameters!', 'info')}
                  className="p-2 border border-slate-200 text-slate-400 hover:text-slate-800 rounded-xl cursor-pointer"
                >
                  <Filter className="w-4 h-4" />
                </button>

                <select
                  value={deptFilter}
                  onChange={(e) => setDeptFilter(e.target.value)}
                  className="bg-slate-50 border border-slate-150 rounded-xl px-3 py-2 text-xs text-slate-700 font-semibold focus:outline-none cursor-pointer"
                >
                  <option value="Marketing">Marketing</option>
                  <option value="Technical">Technical</option>
                  <option value="Business">Business</option>
                </select>

                <select
                  defaultValue="Job Type"
                  className="bg-slate-50 border border-slate-150 rounded-xl px-3 py-2 text-xs text-slate-700 font-semibold focus:outline-none cursor-pointer"
                >
                  <option value="Job Type">Job Type</option>
                  <option value="Full-Time">Full-Time</option>
                  <option value="Remote">Remote</option>
                </select>

                <select
                  defaultValue="Performance"
                  className="bg-slate-50 border border-slate-150 rounded-xl px-3 py-2 text-xs text-slate-700 font-semibold focus:outline-none cursor-pointer"
                >
                  <option value="Performance">Performance</option>
                  <option value="Top Rate">Top Rate</option>
                  <option value="Under Review">Under Review</option>
                </select>

                <div className="ml-auto text-xs font-semibold text-slate-500 flex items-center gap-1.5">
                  <span>Sort by:</span>
                  <select
                    defaultValue="Name"
                    className="bg-slate-50 border border-slate-150 rounded-lg px-2 py-1 text-xs text-slate-700 font-bold focus:outline-none cursor-pointer"
                  >
                    <option value="Name">Name</option>
                    <option value="Rank">Rank</option>
                  </select>
                </div>
              </div>

              {/* Roster Size text header indicator */}
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest pt-1">
                {totalEmployees} employees found
              </div>

              {/* Table rendering panel */}
              <div className="overflow-visible">
                <table className="w-full text-left font-sans text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-[10px] font-black text-slate-400 tracking-wider uppercase">
                      <th className="py-3 px-4">Name</th>
                      <th className="py-3 px-4">Position</th>
                      <th className="py-3 px-4">Department</th>
                      <th className="py-3 px-4">Job Type</th>
                      <th className="py-3 px-4">Address</th>
                      <th className="py-3 px-4 text-center">Rank</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {loadingEmployees ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center">
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Fetching Roster...</span>
                          </div>
                        </td>
                      </tr>
                    ) : employees.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          No employees found.
                        </td>
                      </tr>
                    ) : (
                      employees.map((emp, idx) => {
                        const isActive = selectedDirectoryRow === idx;
                        const initials = emp.user?.fullName?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || '??';
                        const positionTitle =
                          emp.position?.title ||
                          emp.Position?.title ||
                          emp.user?.EmployeeRecord?.position?.title ||
                          emp.user?.EmployeeRecords?.[0]?.position?.title ||
                          emp.metadata?.positionTitle ||
                          emp.metadata?.positionName ||
                          'Position not set';
                        const exemption = exemptionsByUserId.get(getEmployeeUserId(emp));
                        return (
                          <tr
                            key={emp.id}
                            onClick={() => onViewProfile?.(emp)}
                            className={`group transition-all relative cursor-pointer ${isActive
                              ? 'bg-slate-50/70 z-10'
                              : 'hover:bg-slate-50/30'
                              } ${activeActionsMenu === emp.id ? 'z-50' : 'z-0'}`}
                          >
                            {/* Name Column */}
                            <td className="py-3.5 px-4 flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center font-extrabold text-xs shadow-sm border border-white/20">
                                {initials}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 block group-hover:text-blue-600 transition-colors">{emp.user?.fullName}</span>
                                <span className="text-[10.5px] text-slate-400 block mt-0.5">{emp.employeeCode || emp.user?.email}</span>
                                {exemption && (
                                  <span className={`mt-1 inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-black uppercase tracking-wide ${exemption.status === 'APPROVED'
                                      ? 'border-emerald-100 bg-emerald-50 text-emerald-700'
                                      : exemption.status === 'PENDING'
                                        ? 'border-amber-100 bg-amber-50 text-amber-700'
                                        : 'border-slate-100 bg-slate-50 text-slate-500'
                                    }`}>
                                    {exemption.status === 'APPROVED' ? <ShieldCheck className="h-3 w-3" /> : <Clock3 className="h-3 w-3" />}
                                    {exemption.status === 'APPROVED' ? 'Exempted' : exemption.status === 'PENDING' ? 'Exemption pending' : 'Exemption rejected'}
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Position Column */}
                            <td className="py-3 px-4">
                              <span className="inline-flex max-w-[180px] items-center rounded-full border border-blue-100 bg-blue-50 px-2.5 py-1 text-[10.5px] font-bold text-blue-700">
                                <span className="truncate">{positionTitle}</span>
                              </span>
                            </td>

                            {/* Department Column */}
                            <td className="py-3 px-4">
                              <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-200">
                                {emp.department?.name || 'General'}
                              </span>
                            </td>

                            {/* Job Type Column */}
                            <td className="py-3 px-4 font-semibold text-slate-700 capitalize">
                              {emp.employmentType?.replace('_', ' ') || 'full_time'}
                            </td>

                            {/* Address / Contact Info Column */}
                            <td className="py-3 px-4 text-[10.5px] leading-relaxed">
                              <span className="font-semibold text-slate-700 block">{emp.user?.email}</span>
                              <span className="text-slate-400 block font-medium mt-0.5">{emp.user?.phone || 'No Phone'}</span>
                            </td>

                            {/* Performance Rank Column */}
                            <td className="py-3 px-4 text-center">
                              <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-blue-600 bg-blue-50/70 py-1 px-2.5 rounded-full border border-blue-100">
                                <span>✨</span>
                                <span>90%</span>
                              </span>
                            </td>

                            {/* Actions Column */}
                            <td className={`py-3 px-4 text-right relative ${activeActionsMenu === emp.id ? 'z-50' : ''}`}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setActiveActionsMenu(activeActionsMenu === emp.id ? null : emp.id);
                                }}
                                className="p-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all text-slate-400 hover:text-slate-600 cursor-pointer"
                              >
                                <MoreVertical className="w-4 h-4" />
                              </button>

                              <AnimatePresence>
                                {activeActionsMenu === emp.id && (
                                  <>
                                    <div
                                      className="fixed inset-0 z-10"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setActiveActionsMenu(null);
                                      }}
                                    />
                                    <motion.div
                                      initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                      animate={{ opacity: 1, scale: 1, y: 0 }}
                                      exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                      className="absolute right-0 top-8 w-44 bg-white border border-slate-100 rounded-2xl shadow-2xl z-[100] overflow-hidden py-1.5"
                                    >
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onViewProfile?.(emp);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <Eye className="w-3.5 h-3.5" /> View Profile
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setUpdateEmployeeUserId(emp.userId);
                                          setUpdateEmployeeModalOpen(true);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <Pencil className="w-3.5 h-3.5" /> Update Record
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          openPasswordModal(emp);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <Lock className="w-3.5 h-3.5" /> Update Password
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          openRoleModal(emp);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <UserCog className="w-3.5 h-3.5" /> Change Role
                                      </button>
                                      {canAssignContract && (
                                        <EmployeeContractMenuAction
                                          employee={emp}
                                          onAssign={(employee) => {
                                            setContractEmployee(employee);
                                            setActiveActionsMenu(null);
                                          }}
                                          onView={(contractId) => {
                                            setViewerContractId(contractId);
                                            setActiveActionsMenu(null);
                                          }}
                                        />
                                      )}
                                      {canInitializeProbation && (
                                        <button
                                          onClick={(event) => {
                                            event.stopPropagation();
                                            setProbationEmployee(emp);
                                            setActiveActionsMenu(null);
                                          }}
                                          className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                        >
                                          <Hourglass className="w-3.5 h-3.5" />
                                          Initialize Probation
                                        </button>
                                      )}
                                      {exemption?.status === 'APPROVED' && canApproveExemption ? (
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setUnexemptTarget({ employee: emp, exemption });
                                            setActiveActionsMenu(null);
                                          }}
                                          className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                        >
                                          <ShieldCheck className="w-3.5 h-3.5" /> Unexempt User
                                        </button>
                                      ) : canRequestExemption && (
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            openExemptionModal(emp);
                                            setActiveActionsMenu(null);
                                          }}
                                          className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                        >
                                          <ShieldOff className="w-3.5 h-3.5" /> Exempt User
                                        </button>
                                      )}
                                      {canTerminateEmployee && (
                                        <button
                                          onClick={(event) => {
                                            event.stopPropagation();

                                            setTerminationEmployee(emp);
                                            setActiveActionsMenu(null);
                                          }}
                                          className="flex w-full items-center whitespace-nowrap gap-2.5 px-4 py-2 text-[10px] font-bold text-rose-600 transition-colors hover:bg-rose-50"
                                        >
                                          <UserX className="h-3.5 w-3.5" />
                                          Immediate Termination
                                        </button>
                                      )}
                                      <div className="h-[1px] bg-slate-50 my-1" />
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setDeleteEmployeeUserId(emp.userId);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-rose-500 hover:bg-rose-50 transition-colors"
                                      >
                                        <Trash className="w-3.5 h-3.5" /> Delete Record
                                      </button>
                                    </motion.div>
                                  </>
                                )}
                              </AnimatePresence>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Navigation Pagination controls footer block */}
              <div className="flex justify-center items-center gap-1.5 pt-4 border-t border-slate-50">
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(p => p - 1)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {Array.from({ length: Math.ceil(totalEmployees / employeesPerPage) }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`w-7 h-7 font-black text-xs rounded-full flex items-center justify-center cursor-pointer transition-all ${currentPage === i + 1
                        ? 'bg-blue-600 text-white shadow-md scale-110'
                        : 'text-slate-500 hover:bg-slate-50 font-bold'
                      }`}
                  >
                    {i + 1}
                  </button>
                ))}

                {totalEmployees === 0 && (
                  <button className="w-7 h-7 bg-blue-600 text-white font-black text-xs rounded-full flex items-center justify-center cursor-pointer">
                    1
                  </button>
                )}

                <button
                  disabled={currentPage >= Math.ceil(totalEmployees / employeesPerPage)}
                  onClick={() => setCurrentPage(p => p + 1)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          </motion.div>
        )}

        {currentProfilesTab === 'left' && (
          <motion.div
            key="left"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div className="flex justify-between items-end">
              <div>
                <h4 className="text-sm font-bold text-slate-950 tracking-tight">Left Employees</h4>
                <p className="text-[11px] text-slate-500 font-medium">Employees whose offboarding has been finally approved</p>
              </div>
              <button
                onClick={() => refetchLeftEmployees()}
                disabled={loadingLeftEmployees}
                className="text-[10px] font-black text-blue-600 flex items-center gap-1 hover:underline disabled:opacity-50"
              >
                {loadingLeftEmployees ? 'Refreshing...' : 'Refresh'}
              </button>
            </div>
            <div className="bg-white border border-slate-150 rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                {totalLeftEmployees} left employees found
              </div>
              <table className="w-full text-left font-sans text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[10px] font-black text-slate-400 tracking-wider uppercase">
                    <th className="py-3 px-4">Name</th>
                    <th className="py-3 px-4">Position</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {loadingLeftEmployees ? (
                    <tr><td colSpan={5} className="py-12 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">Loading left employees...</td></tr>
                  ) : leftEmployees.length === 0 ? (
                    <tr><td colSpan={5} className="py-12 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">No left employees found.</td></tr>
                  ) : leftEmployees.map((emp) => (
                    <tr key={emp.id} onClick={() => onViewProfile?.(emp)} className="hover:bg-slate-50/50 cursor-pointer">
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900 block">{emp.user?.fullName || emp.user?.email || 'Employee'}</span>
                        <span className="text-[10.5px] text-slate-400 block mt-0.5">{emp.employeeCode || '-'}</span>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{emp.position?.title || emp.Position?.title || 'Position not set'}</td>
                      <td className="py-3 px-4 text-slate-700">{emp.department?.name || 'General'}</td>
                      <td className="py-3 px-4 text-slate-500">{emp.user?.email || '-'}</td>
                      <td className="py-3 px-4">
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-200">Left</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {currentProfilesTab === 'interns' && (
          <motion.div
            key="interns"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div className="flex justify-between items-end">
              <div>
                <h4 className="text-sm font-bold text-slate-950 tracking-tight">Interns</h4>
                <p className="text-[11px] text-slate-500 font-medium">Create, edit, and track internship records</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setCreateInternModalOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-[11px] font-black text-white hover:bg-blue-700"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Intern
                </button>
                <button
                  onClick={() => refetchInterns()}
                  disabled={loadingInterns}
                  className="text-[10px] font-black text-blue-600 flex items-center gap-1 hover:underline disabled:opacity-50"
                >
                  {loadingInterns ? 'Reloading...' : 'Reload Interns'}
                </button>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-xs space-y-4">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest pt-1">
                {totalInterns} interns found
              </div>

              <div className="overflow-visible">
                <table className="w-full text-left font-sans text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-[10px] font-black text-slate-400 tracking-wider uppercase">
                      <th className="py-3 px-4">Name</th>
                      <th className="py-3 px-4">Program</th>
                      <th className="py-3 px-4">Department</th>
                      <th className="py-3 px-4">Expected End</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {loadingInterns ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center">
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Fetching Interns...</span>
                          </div>
                        </td>
                      </tr>
                    ) : interns.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          No interns found.
                        </td>
                      </tr>
                    ) : (
                      interns.map((intern) => {
                        const internship = intern.metadata?.internship || {};
                        const initials = intern.user?.fullName?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || '??';
                        return (
                          <tr
                            key={intern.id}
                            onClick={() => onViewProfile?.(intern)}
                            className={`group transition-all relative cursor-pointer hover:bg-slate-50/30 ${activeActionsMenu === intern.id ? 'z-50' : 'z-0'}`}
                          >
                            <td className="py-3.5 px-4 flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center font-extrabold text-xs shadow-sm border border-white/20">
                                {initials}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 block group-hover:text-blue-600 transition-colors">{intern.user?.fullName}</span>
                                <span className="text-[10.5px] text-slate-400 block mt-0.5">{intern.employeeCode || intern.user?.email}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-bold text-slate-700">{internship.program || intern.position?.title || 'Program not set'}</span>
                              <span className="block text-[10px] text-slate-400 mt-0.5">{internship.institution || 'Institution not set'}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-200">
                                {intern.department?.name || 'General'}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-[10.5px] font-semibold text-slate-600">
                              {internship.expectedEndDate ? new Date(internship.expectedEndDate).toLocaleDateString() : 'Not set'}
                            </td>
                            <td className="py-3 px-4">
                              <span className="inline-flex rounded-full border border-blue-100 bg-blue-50 px-2.5 py-1 text-[10.5px] font-bold capitalize text-blue-700">
                                {internship.status || intern.employmentStatus || 'active'}
                              </span>
                            </td>
                            <td className={`py-3 px-4 text-right relative ${activeActionsMenu === intern.id ? 'z-50' : ''}`}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setActiveActionsMenu(activeActionsMenu === intern.id ? null : intern.id);
                                }}
                                className="p-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all text-slate-400 hover:text-slate-600 cursor-pointer"
                              >
                                <MoreVertical className="w-4 h-4" />
                              </button>
                              <AnimatePresence>
                                {activeActionsMenu === intern.id && (
                                  <>
                                    <div className="fixed inset-0 z-10" onClick={(e) => { e.stopPropagation(); setActiveActionsMenu(null); }} />
                                    <motion.div
                                      initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                      animate={{ opacity: 1, scale: 1, y: 0 }}
                                      exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                      className="absolute right-0 top-8 w-44 bg-white border border-slate-100 rounded-2xl shadow-2xl z-[100] overflow-hidden py-1.5"
                                    >
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onViewProfile?.(intern);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <Eye className="w-3.5 h-3.5" /> View Profile
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setUpdateEmployeeUserId(intern.userId);
                                          setUpdateEmployeeModalOpen(true);
                                          setActiveActionsMenu(null);
                                        }}
                                        className="w-full flex items-center gap-2.5 px-4 py-2 text-[11px] font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                      >
                                        <Pencil className="w-3.5 h-3.5" /> Update Intern
                                      </button>
                                    </motion.div>
                                  </>
                                )}
                              </AnimatePresence>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-center items-center gap-1.5 pt-4 border-t border-slate-50">
                <button
                  disabled={internsPage === 1}
                  onClick={() => setInternsPage(p => p - 1)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                {Array.from({ length: Math.ceil(totalInterns / employeesPerPage) }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setInternsPage(i + 1)}
                    className={`w-7 h-7 font-black text-xs rounded-full flex items-center justify-center cursor-pointer transition-all ${internsPage === i + 1 ? 'bg-blue-600 text-white shadow-md scale-110' : 'text-slate-500 hover:bg-slate-50 font-bold'
                      }`}
                  >
                    {i + 1}
                  </button>
                ))}
                {totalInterns === 0 && (
                  <button className="w-7 h-7 bg-blue-600 text-white font-black text-xs rounded-full flex items-center justify-center cursor-pointer">
                    1
                  </button>
                )}
                <button
                  disabled={internsPage >= Math.ceil(totalInterns / employeesPerPage)}
                  onClick={() => setInternsPage(p => p + 1)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {currentProfilesTab === 'organization' && (
          <motion.div
            key="organization"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <DepartmentsPositionsTab showAlert={showAlert} />
          </motion.div>
        )}

        {currentProfilesTab === 'devices' && (
          <motion.div
            key="devices"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <EmployeeDevicesTab showAlert={showAlert} />
          </motion.div>
        )}

        {/* --- 5. EVENTS SCREEN --- */}
        {currentProfilesTab === 'events' && (
          <motion.div
            key="events"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <EventsTab showAlert={showAlert} />
          </motion.div>
        )}
<ImmediateTerminationModal
  isOpen={Boolean(terminationEmployee)}
  employee={terminationEmployee}
  onClose={() =>
    setTerminationEmployee(null)
  }
  showAlert={showAlert}
        />
        {/* --- 6. ARCHIVE SCREEN (IMAGE 6) --- */}
        {currentProfilesTab === 'archive' && (
          <motion.div
            key="archive"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div>
              <h4 className="text-sm font-bold text-slate-950 tracking-tight">Offboarded Employee History</h4>
              <p className="text-[11px] text-slate-500 font-medium font-sans">Archived data of no longer active employees.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

              {/* Left Column (Lists & searching parameters) */}
              <div className="lg:col-span-6 bg-white rounded-3xl border border-slate-100 p-5 space-y-4 shadow-xs">

                {/* Search box inside container */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={archiveSearch}
                    onChange={(e) => setArchiveSearch(e.target.value)}
                    placeholder="Search archived employees..."
                    className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-150 rounded-xl py-2.5 pl-10 pr-4 text-xs font-semibold text-slate-700 placeholder-slate-400 focus:outline-none focus:bg-white"
                  />
                </div>

                {/* Filters */}
                <div className="flex gap-2.5">
                  <button className="p-2 border border-slate-200 text-slate-400 rounded-xl">
                    <Filter className="w-4 h-4" />
                  </button>
                  <select
                    value={archiveDeptFilter}
                    onChange={(e) => setArchiveDeptFilter(e.target.value)}
                    className="bg-slate-50 border border-slate-150 rounded-xl px-3 py-2 text-xs text-slate-700 font-semibold focus:outline-none cursor-pointer"
                  >
                    <option value="Marketing">Marketing</option>
                    <option value="Technical">Technical</option>
                  </select>
                </div>

                {/* size metadata */}
                <div className="flex justify-between items-center pt-2">
                  <span className="text-[11px] font-bold text-slate-400 tracking-wider uppercase">8 employees found</span>
                  <span className="text-[11px] font-semibold text-slate-500">Sort by: Name</span>
                </div>

                {/* List items block */}
                <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                  {[0, 1, 2, 3, 4, 5, 6, 7].map((val) => {
                    const isActive = selectedArchiveRow === val;
                    return (
                      <div
                        key={val}
                        onClick={() => setSelectedArchiveRow(val)}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${isActive
                          ? 'bg-slate-50/70 border-2 border-blue-600/30'
                          : 'bg-white border-slate-50 hover:bg-slate-50/50'
                          }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-[#1e64f2] text-white flex items-center justify-center font-bold">
                            JP
                          </div>
                          <div>
                            <h5 className="text-[12.5px] font-bold text-slate-900 leading-none">Jessica Parker</h5>
                            <span className="text-[10px] text-slate-400 mt-1.5 block">Full Stack Developer</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-[11px] font-bold text-slate-700 block">{archiveDeptFilter}</span>
                          <span className="text-[10px] text-slate-400 mt-1 block">Exited at: Dec 15, 2024</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Pagination Controls */}
                <div className="flex justify-center items-center gap-1.5 pt-4 border-t border-slate-50">
                  <button className="p-1 rounded border border-slate-200 text-slate-400">
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button className="w-6 h-6 bg-blue-600 text-white font-bold text-xs rounded-full flex items-center justify-center">1</button>
                  <button className="w-6 h-6 font-bold text-slate-400 hover:bg-slate-100 text-xs rounded-full flex items-center justify-center">2</button>
                  <button className="w-6 h-6 font-bold text-slate-400 hover:bg-slate-100 text-xs rounded-full flex items-center justify-center">3</button>
                  <button className="w-6 h-6 font-bold text-slate-400 hover:bg-slate-100 text-xs rounded-full flex items-center justify-center">4</button>
                  <button className="p-1 rounded border border-slate-200 text-slate-400">
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Right Column (Detailed Archived Employee specifications sheet) */}
              <div className="lg:col-span-6 bg-white rounded-3xl border border-slate-100 p-6 space-y-6 shadow-xs">

                {/* Header Profile Info block */}
                <div className="flex justify-between items-start flex-wrap gap-3 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 text-white font-extrabold rounded-full flex items-center justify-center text-sm shadow-md">
                      JP
                    </div>
                    <div>
                      <h4 className="text-base font-black text-slate-900 leading-none">Jessica Parker</h4>
                      <p className="text-xs font-semibold text-slate-400 mt-1">Full Stack Developer</p>
                      <p className="text-[10px] text-slate-400/80 mt-0.5">jessica@company.com &bull; +251 987 76 6353</p>
                    </div>
                  </div>

                  <span className="bg-blue-50 text-[#1a56db] font-extrabold text-[10px] uppercase tracking-wider px-3 py-1 rounded-lg border border-blue-100/50">
                    TECHNICAL DEPT.
                  </span>
                </div>

                {/* Employment Section */}
                <div className="bg-slate-50/70 border border-slate-100 p-4.5 rounded-2xl space-y-3.5">
                  <h5 className="text-[11px] font-extrabold text-slate-400 uppercase tracking-widest leading-none">Employment</h5>

                  <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-xs text-slate-500 font-semibold">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Start Date</span>
                      <span className="text-slate-800 font-bold block">Dec 15, 2024</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Total Tenure</span>
                      <span className="text-slate-800 font-bold block">2 years, 8 months</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">End Date</span>
                      <span className="text-slate-800 font-bold block">Dec 15, 2024</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Salary</span>
                      <span className="text-slate-800 font-black block">20,000 ETB</span>
                    </div>
                  </div>
                </div>

                {/* Offboarding Details Section */}
                <div className="bg-slate-50/70 border border-slate-100 p-4.5 rounded-2xl space-y-3.5">
                  <h5 className="text-[11px] font-extrabold text-slate-400 uppercase tracking-widest leading-none">Offboarding Details</h5>

                  {/* Resignation Letter date line */}
                  <div className="bg-blue-50/55 border border-blue-100/40 p-3 rounded-xl flex items-center justify-between text-xs text-blue-800">
                    <span className="font-bold flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span>Resignation letter sent on:</span>
                    </span>
                    <strong className="font-black text-blue-900">Dec 30, 2025</strong>
                  </div>

                  {/* Leaving reason and AI status */}
                  <div className="grid grid-cols-2 gap-4 pt-1.5">
                    <div className="space-y-1">
                      <span className="text-[9.5px] font-bold text-slate-400 uppercase tracking-wider block">Reason for Leaving ✨</span>
                      <p className="text-[11px] font-bold text-slate-800 leading-snug">Resignation - Better Opportunity</p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[9.5px] font-bold text-slate-400 uppercase tracking-wider block">Exit & Clearance</span>
                      <span className="inline-flex bg-emerald-50 text-emerald-700 font-extrabold text-[10px] uppercase py-1 px-3.5 rounded-lg border border-emerald-100">
                        Completed
                      </span>
                    </div>
                  </div>

                  {/* Top Sparkle AI score card layout */}
                  <div className="bg-blue-50/70 border border-blue-100 p-4 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black tracking-widest text-[#1e64f2] uppercase block">AI Score</span>
                      <p className="text-[10px] font-bold text-slate-400 mt-1">Overall Performance</p>
                    </div>

                    <div className="flex items-center gap-1 text-2xl font-black text-blue-600">
                      <span>✨</span>
                      <span>87%</span>
                    </div>
                  </div>
                </div>

                {/* Archived documents list block */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <h5 className="text-[11px] font-extrabold text-slate-400 uppercase tracking-widest">Archived Documents</h5>
                    <span className="bg-slate-100 text-slate-600 font-black px-2 py-0.5 rounded-md text-[10px] tracking-tight">24 files</span>
                  </div>

                  {/* Grid of four interactive file tags */}
                  <div className="grid grid-cols-2 gap-3 text-xs font-semibold text-slate-700">

                    <button
                      onClick={() => showAlert('Opening archived Contract file', 'success')}
                      className="bg-white hover:bg-slate-50 border border-slate-150 rounded-xl p-3 flex items-center justify-between select-none cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <span className="truncate">Contract</span>
                      </div>
                      <Download className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600" />
                    </button>

                    <button
                      onClick={() => showAlert('Downloading Performance Reviews metrics log', 'success')}
                      className="bg-white hover:bg-slate-50 border border-slate-150 rounded-xl p-3 flex items-center justify-between select-none cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-slate-400" />
                        <span className="truncate">Performance R...</span>
                      </div>
                      <Download className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600" />
                    </button>

                    <button
                      onClick={() => showAlert('Extracting Exit Interview notes', 'success')}
                      className="bg-white hover:bg-slate-50 border border-slate-150 rounded-xl p-3 flex items-center justify-between select-none cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-400" />
                        <span className="truncate">Exit Interview</span>
                      </div>
                      <Download className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600" />
                    </button>

                    <button
                      onClick={() => showAlert('Downloading scanning ID Documents archive', 'success')}
                      className="bg-white hover:bg-slate-50 border border-slate-150 rounded-xl p-3 flex items-center justify-between select-none cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-400" />
                        <span className="truncate">ID Document</span>
                      </div>
                      <Download className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600" />
                    </button>

                  </div>
                </div>

                {/* Bottom Main Actions */}
                <div className="flex gap-3 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => showAlert('Opening complete offboarding record ledger', 'success')}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer text-center"
                  >
                    View Record
                  </button>
                  <button
                    onClick={() => showAlert('Packaging all 24 archived files for download', 'success')}
                    className="flex-1 bg-slate-100 hover:bg-slate-250 text-slate-700 font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer text-center"
                  >
                    Download Files
                  </button>
                </div>

              </div>

            </div>
          </motion.div>
        )}

      </AnimatePresence>

      {/* ── Pending Registrations Tab ── */}
      {currentProfilesTab === 'pending_registrations' && (
        <PendingRegistrationsTab showAlert={showAlert} />
      )}

      {currentProfilesTab === 'exemption_requests' && (
        <motion.div
          key="exemption_requests"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="space-y-5"
        >
          <div className="flex items-end justify-between">
            <div>
              <h4 className="text-sm font-black text-slate-950 tracking-tight">User Exemption Requests</h4>
              <p className="text-[11px] text-slate-500 font-medium">Pending requests awaiting Business Admin approval.</p>
            </div>
            <button
              onClick={() => exemptionRequests.refetch()}
              disabled={exemptionRequests.isLoading}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[11px] font-black text-slate-600 hover:bg-slate-50 disabled:opacity-50"
            >
              {exemptionRequests.isLoading ? 'Loading...' : 'Refresh'}
            </button>
          </div>

          <div className="overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-black uppercase tracking-widest text-slate-400">
                <tr>
                  <th className="px-5 py-3">Employee</th>
                  <th className="px-5 py-3">Reason</th>
                  <th className="px-5 py-3">Payroll</th>
                  <th className="px-5 py-3">Requested By</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {exemptionRequests.isLoading ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-10 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">Loading requests...</td>
                  </tr>
                ) : (exemptionRequests.data?.rows || []).length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-10 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">No pending exemption requests.</td>
                  </tr>
                ) : (
                  (exemptionRequests.data?.rows || []).map((request) => (
                    <tr key={request.id} className="align-top">
                      <td className="px-5 py-4">
                        <div className="font-black text-slate-900">{request.user?.fullName || 'Unknown user'}</div>
                        <div className="mt-0.5 text-[10.5px] font-semibold text-slate-400">{request.user?.email || 'No email'}</div>
                      </td>
                      <td className="max-w-md px-5 py-4 text-[11px] font-semibold leading-5 text-slate-600">{request.reason}</td>
                      <td className="px-5 py-4">
                        <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-black ${request.excludeFromPayroll
                            ? 'border-rose-100 bg-rose-50 text-rose-600'
                            : 'border-emerald-100 bg-emerald-50 text-emerald-700'
                          }`}>
                          {request.excludeFromPayroll ? 'Excluded' : 'Included'}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-bold text-slate-700">{request.requester?.fullName || 'Unknown'}</div>
                        <div className="mt-0.5 text-[10.5px] font-semibold text-slate-400">{request.createdAt ? new Date(request.createdAt).toLocaleDateString() : ''}</div>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => handleRejectExemption(request.id)}
                            disabled={!canApproveExemption || rejectExemptionMutation.isPending || approveExemptionMutation.isPending}
                            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-100 bg-white px-3 py-2 text-[11px] font-black text-rose-600 hover:bg-rose-50 disabled:opacity-50"
                          >
                            <XCircle className="h-3.5 w-3.5" /> Reject
                          </button>
                          <button
                            onClick={() => handleApproveExemption(request.id)}
                            disabled={!canApproveExemption || rejectExemptionMutation.isPending || approveExemptionMutation.isPending}
                            className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-2 text-[11px] font-black text-white hover:bg-blue-700 disabled:bg-slate-300"
                          >
                            <ShieldCheck className="h-3.5 w-3.5" /> Approve
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      <CreateEmployeeModal
        isOpen={createInternModalOpen}
        onClose={() => setCreateInternModalOpen(false)}
        showAlert={showAlert}
        initialEmploymentType="intern"
        onSuccess={() => {
          setCreateInternModalOpen(false);
          refetchInterns();
          refetchEmployees();
        }}
      />

      <CreateEmployeeModal
        isOpen={updateEmployeeModalOpen}
        onClose={() => {
          setUpdateEmployeeModalOpen(false);
          setUpdateEmployeeUserId(null);
        }}
        showAlert={showAlert}
        mode="update"
        targetUserId={updateEmployeeUserId || undefined}
        onSuccess={() => {
          fetchEmployees(currentPage);
          refetchInterns();
        }}
      />

      <AnimatePresence>
        {passwordEmployee && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/40 px-4"
            onClick={closePasswordModal}
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 16 }}
              onSubmit={handlePasswordUpdate}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md rounded-3xl border border-slate-100 bg-white p-6 shadow-2xl"
            >
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                  <Lock className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-black text-slate-950 tracking-tight">Update Password</h4>
                  <p className="mt-1 text-[11px] font-medium text-slate-500">
                    Set a new password for {passwordEmployee.user?.fullName || 'this employee'}.
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-4">
                <label className="block space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">New Password</span>
                  <input
                    type="password"
                    value={passwordForm.password}
                    onChange={(e) => {
                      setPasswordForm((prev) => ({ ...prev, password: e.target.value }));
                      setPasswordError('');
                    }}
                    className="w-full rounded-xl border border-slate-150 bg-slate-50 px-3.5 py-2.5 text-xs font-semibold text-slate-700 outline-none transition-colors hover:bg-slate-100 focus:bg-white focus:border-blue-200"
                    placeholder="Enter new password"
                    autoComplete="new-password"
                  />
                </label>
                <label className="block space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Confirm Password</span>
                  <input
                    type="password"
                    value={passwordForm.confirmPassword}
                    onChange={(e) => {
                      setPasswordForm((prev) => ({ ...prev, confirmPassword: e.target.value }));
                      setPasswordError('');
                    }}
                    className="w-full rounded-xl border border-slate-150 bg-slate-50 px-3.5 py-2.5 text-xs font-semibold text-slate-700 outline-none transition-colors hover:bg-slate-100 focus:bg-white focus:border-blue-200"
                    placeholder="Re-enter new password"
                    autoComplete="new-password"
                  />
                </label>
                {passwordError && (
                  <p className="rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-600">
                    {passwordError}
                  </p>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={closePasswordModal}
                  disabled={updatePasswordMutation.isPending}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updatePasswordMutation.isPending}
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-black text-white transition-colors hover:bg-blue-700 disabled:bg-slate-300"
                >
                  {updatePasswordMutation.isPending ? 'Saving...' : 'Update Password'}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {exemptionEmployee && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/40 px-4"
            onClick={closeExemptionModal}
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 16 }}
              onSubmit={handleExemptionSubmit}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg rounded-3xl border border-slate-100 bg-white p-6 shadow-2xl"
            >
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                  <ShieldOff className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-black text-slate-950 tracking-tight">Exempt User</h4>
                  <p className="mt-1 text-[11px] font-medium text-slate-500">
                    Submit an exemption request for {exemptionEmployee.user?.fullName || 'this employee'}.
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-4">
                <label className="block space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Exemption Reason</span>
                  <textarea
                    value={exemptionForm.reason}
                    onChange={(e) => {
                      setExemptionForm((prev) => ({ ...prev, reason: e.target.value }));
                      setExemptionError('');
                    }}
                    rows={5}
                    className="w-full resize-none rounded-xl border border-slate-150 bg-slate-50 px-3.5 py-2.5 text-xs font-semibold text-slate-700 outline-none transition-colors hover:bg-slate-100 focus:bg-white focus:border-blue-200"
                    placeholder="Explain why this user should be exempted"
                  />
                </label>
                <label className="flex items-start gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={exemptionForm.excludeFromPayroll}
                    onChange={(e) => setExemptionForm((prev) => ({ ...prev, excludeFromPayroll: e.target.checked }))}
                    className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-200"
                  />
                  <span>
                    <span className="block text-xs font-black text-slate-800">Exclude from payroll calculation</span>
                    <span className="mt-1 block text-[11px] font-medium text-slate-500">
                      Leave unchecked to exempt attendance penalties while keeping salary generation active.
                    </span>
                  </span>
                </label>
                {exemptionError && (
                  <p className="rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-600">
                    {exemptionError}
                  </p>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={closeExemptionModal}
                  disabled={createExemptionMutation.isPending}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createExemptionMutation.isPending}
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-black text-white transition-colors hover:bg-blue-700 disabled:bg-slate-300"
                >
                  {createExemptionMutation.isPending ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {roleEmployee && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/40 px-4"
            onClick={closeRoleModal}
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 16 }}
              onSubmit={handleRoleUpdate}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md rounded-3xl border border-slate-100 bg-white p-6 shadow-2xl"
            >
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                  <UserCog className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-black text-slate-950 tracking-tight">Change Role</h4>
                  <p className="mt-1 text-[11px] font-medium text-slate-500">
                    Update the system role for {roleEmployee.user?.fullName || 'this employee'}.
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-4">
                <div className="rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                  <span className="block text-[10px] font-black uppercase tracking-widest text-slate-400">Current Role</span>
                  <span className="mt-1 block text-xs font-black text-slate-800">{getEmployeeRoleLabel(roleEmployee)}</span>
                </div>
                <label className="block space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">New Role</span>
                  <Select
                    value={selectedRoleKey}
                    onValueChange={(value) => {
                      setSelectedRoleKey(value);
                      setRoleError('');
                    }}
                    disabled={loadingRoles || updateRoleMutation.isPending}
                  >
                    <SelectTrigger className="h-11 w-full rounded-xl border-slate-150 bg-slate-50 px-3.5 text-xs font-semibold text-slate-700 shadow-none hover:bg-slate-100 focus:bg-white focus:border-blue-200">
                      <SelectValue placeholder={loadingRoles ? 'Loading roles...' : 'Select role'} />
                    </SelectTrigger>
                    <SelectContent
                      align="start"
                      sideOffset={6}
                      className="max-h-64 rounded-xl border border-slate-100 bg-white p-1 shadow-2xl"
                    >
                      {allRoles.map((role: any) => (
                        <SelectItem key={role.id || role.key} value={role.key} className="text-xs font-semibold">
                          {role.name || role.key}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>
                {selectedRoleKey && (
                  <p className="text-[11px] font-semibold text-slate-500">
                    This will assign {selectedRoleLabel} to the selected employee.
                  </p>
                )}
                {roleError && (
                  <p className="rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-600">
                    {roleError}
                  </p>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={closeRoleModal}
                  disabled={updateRoleMutation.isPending}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updateRoleMutation.isPending || loadingRoles}
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-black text-white transition-colors hover:bg-blue-700 disabled:bg-slate-300"
                >
                  {updateRoleMutation.isPending ? 'Saving...' : 'Save Role'}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        open={!!deleteEmployeeUserId}
        onClose={() => setDeleteEmployeeUserId(null)}
        onConfirm={() => deleteEmployeeUserId && handleDeleteEmployee(deleteEmployeeUserId)}
        title="Delete Employee Record"
        description="Are you sure you want to delete this employee record?"
        confirmLabel="Delete"
        variant="destructive"
        loading={deleteEmployeeMutation.isPending}
      />

      <ConfirmDialog
        open={!!unexemptTarget}
        onClose={() => setUnexemptTarget(null)}
        onConfirm={handleUnexemptUser}
        title="Unexempt User"
        description={`Remove the active exemption for ${unexemptTarget?.employee?.user?.fullName || 'this user'}? They will return to attendance check-in requirements and payroll handling based on their normal employee setup.`}
        confirmLabel="Unexempt"
        loading={revokeExemptionMutation.isPending}
      />

      {probationEmployee && (
        <InitializeProbationDialog
          isOpen={Boolean(probationEmployee)}
          employeeUserId={getEmployeeUserId(probationEmployee)}
          employeeName={
            probationEmployee?.user?.fullName ||
            probationEmployee?.User?.fullName ||
            probationEmployee?.fullName ||
            probationEmployee?.user?.email ||
            "Employee"
          }
          positionId={
            probationEmployee?.position?.id ||
            probationEmployee?.Position?.id ||
            probationEmployee?.positionId ||
            probationEmployee?.user?.EmployeeRecord?.positionId ||
            probationEmployee?.user?.EmployeeRecords?.[0]?.positionId ||
            null
          }
          positionTitle={
            probationEmployee?.position?.title ||
            probationEmployee?.Position?.title ||
            probationEmployee?.user?.EmployeeRecord?.position?.title ||
            probationEmployee?.user?.EmployeeRecords?.[0]?.position?.title ||
            probationEmployee?.metadata?.positionTitle ||
            probationEmployee?.metadata?.positionName ||
            null
          }
          departmentName={
            probationEmployee?.department?.name ||
            probationEmployee?.Department?.name ||
            probationEmployee?.user?.EmployeeRecord?.department?.name ||
            probationEmployee?.user?.EmployeeRecords?.[0]?.department?.name ||
            null
          }
          currentManagerUserId={
            probationEmployee?.managerUserId ||
            probationEmployee?.manager?.id ||
            probationEmployee?.Manager?.id ||
            probationEmployee?.user?.EmployeeRecord?.managerUserId ||
            probationEmployee?.user?.EmployeeRecords?.[0]?.managerUserId ||
            null
          }
          defaultStartDate={
            probationEmployee?.hireDate ||
            probationEmployee?.contractStartDate ||
            probationEmployee?.user?.EmployeeRecord?.hireDate ||
            probationEmployee?.user?.EmployeeRecords?.[0]?.hireDate ||
            probationEmployee?.createdAt ||
            null
          }
          onClose={() => setProbationEmployee(null)}
          onSuccess={() => {
            setProbationEmployee(null);
            refetchEmployees();
            refetchOrg();
            showAlert("Employee probation initialized successfully", "success");
          }}
        />
      )}

      <AssignEmployeeContractModal
        isOpen={Boolean(contractEmployee)}
        employee={contractEmployee}
        onClose={() => setContractEmployee(null)}
        showAlert={showAlert}
        onAssigned={() => {
          setContractEmployee(null);
          refetchEmployees();
          showAlert('Employment contract assigned successfully', 'success');
        }}
      />

      <EmployeeContractViewerModal
        isOpen={Boolean(viewerContractId)}
        contractId={viewerContractId}
        onClose={() => setViewerContractId(null)}
      />
    </div>
  );
}
