export { default } from './ExitProgressBar';
